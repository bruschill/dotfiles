#!/usr/bin/env python
#
# GUI to change position of the notify-osd-bubble
#
# Depends on python-gconf
#
# Author: Krytarik
#
# 1 - top-right corner
# 2 - middle-right
# 3 - bottom-right corner
# 4 - bottom-left corner
# 5 - middle-left
# 6 - top-left corner
#

import gtk
import gconf

def callback(button, client):
    global p1, p2, p3, p4, p5, p6, key, entry
    if p1.get_active():
    	entry = 1
    elif p2.get_active():
    	entry = 2
    elif p3.get_active():
    	entry = 3
    elif p4.get_active():
    	entry = 4
    elif p5.get_active():
    	entry = 5
    elif p6.get_active():
    	entry = 6
    client.set_int (key, entry)

# Gconf stuff
client = gconf.client_get_default ()
key = "/apps/notify-osd/gravity"

# Gtk window
window = gtk.Window()
window.set_geometry_hints(min_width=220, min_height=140, max_width=-1, max_height=-1, base_width=-1, base_height=-1, width_inc=-1, height_inc=-1, min_aspect=-1.0, max_aspect=-1.0)
window.set_title("Notification-Bubble")
p1 = gtk.RadioButton(group=None, label='top right')
p2 = gtk.RadioButton(p1, label='middle right')
p3 = gtk.RadioButton(p1, label='bottom right')
p6 = gtk.RadioButton(p1, label='top left')
p5 = gtk.RadioButton(p1, label='middle left')
p4 = gtk.RadioButton(p1, label='bottom left')
box1 = gtk.VBox(False, 0)
box1.add(gtk.Label("Choose position: "))
box2 = gtk.VBox(False, 0)
box2.add(p1)
box2.add(p2)
box2.add(p3)
box3 = gtk.VBox(False, 0)
box3.add(p6)
box3.add(p5)
box3.add(p4)
table = gtk.Table(rows=3, columns=4, homogeneous=False)
table.attach(box2, 3, 4, 1, 3, xoptions=gtk.EXPAND, yoptions=gtk.EXPAND, xpadding=0, ypadding=0)
table.attach(box3, 1, 2, 1, 3, xoptions=gtk.EXPAND, yoptions=gtk.EXPAND, xpadding=0, ypadding=0)
box1.add(table)
done = gtk.Button('Done')
box4 = gtk.HButtonBox()
box4.add(done)
box1.add(box4)
window.add (box1)
window.show_all ()

# Widget events
window.connect('delete_event', gtk.main_quit)
done.connect('clicked', gtk.main_quit)
p1.connect ('toggled', callback, client)
p2.connect ('toggled', callback, client)
p3.connect ('toggled', callback, client)
p6.connect ('toggled', callback, client)
p5.connect ('toggled', callback, client)
p4.connect ('toggled', callback, client)

# If key isn't writable, then set insensitive
p1.set_sensitive (client.key_is_writable (key))
p2.set_sensitive (client.key_is_writable (key))
p3.set_sensitive (client.key_is_writable (key))
p6.set_sensitive (client.key_is_writable (key))
p5.set_sensitive (client.key_is_writable (key))
p4.set_sensitive (client.key_is_writable (key))

# Get current settings
entry=client.get_int(key)
if entry == 1:
	p1.set_active(True)
elif entry == 2:
	p2.set_active(True)
elif entry == 3:
	p3.set_active(True)
elif entry == 4:
	p4.set_active(True)
elif entry == 5:
	p5.set_active(True)
elif entry == 6:
	p6.set_active(True)

gtk.main ()

